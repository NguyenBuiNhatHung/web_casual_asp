﻿namespace DoAn_63134144.Controllers
{
    public class RegisterViewModel
    {
        public string Email { get; internal set; }
    }
}