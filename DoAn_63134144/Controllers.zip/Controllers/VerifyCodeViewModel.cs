﻿
namespace DoAn_63134144.Controllers
{
    public class VerifyCodeViewModel
    {
        public string Email { get; set; }
        public string Code {  get; set; }   
        
    }
}